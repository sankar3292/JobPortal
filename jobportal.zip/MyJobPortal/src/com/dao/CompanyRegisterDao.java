package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.bean.CompanyBean;
import com.util.DBConnection;

public class CompanyRegisterDao 
{
	public static String registerEmployer(CompanyBean companyBean)
	{
		 String companyname=companyBean.getCompany_name();
		 String companyemail=companyBean.getCompany_email();
		 String companyaddress=companyBean.getCompany_address();
		 String companyphone=companyBean.getCompany_phone();
		 String companypassword=companyBean.getCompany_password();
		 String companyindustry=companyBean.getCompany_industry();
		 String companycountry=companyBean.getCompany_country();
		 Connection con = null;
		 PreparedStatement preparedStatement = null;
		 try
		 {
		 con = DBConnection.createConnection();
		 String query = "insert into company_account(company_name,company_email,company_password,company_address,company_industry,company_country,company_phone) values (?,?,?,?,?,?,?)";
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 preparedStatement.setString(1,companyname);
		 preparedStatement.setString(2,companyemail);
		 preparedStatement.setString(3,companypassword);
		 preparedStatement.setString(4,companyaddress);
		 preparedStatement.setString(5,companyindustry);
		 preparedStatement.setString(6,companycountry); 
		 preparedStatement.setString(7,companyphone); 
		 int i= preparedStatement.executeUpdate();
		 if (i!=0)  //Just to ensure data has been inserted into the database
		 return "SUCCESS"; 
		
		 }
		 catch (Exception e) 
		 {
			// TODO: handle exception
			 e.printStackTrace();
			 System.out.println("sql error:"+e.getMessage());
			 
		}
		
		 
		 return "Oops.. Something went wrong there..!";  // On failure, send a message from here.
    }
	
}
