package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.bean.JobBean;
import com.bean.RegisterBean;
import com.util.DBConnection;

public class PostJobDao 
{
	public static String postJob(JobBean jobBean)
	{
		 String jobtitle=jobBean.getJob_title();
		 String jobdescription=jobBean.getJob_description();
		 String companyid=jobBean.getCompany_id();
		 String jobdate=jobBean.getJob_date();
		 String jobpost_date=jobBean.getJob_postdate();
		 Connection con = null;
		 PreparedStatement preparedStatement = null;
		 try
		 {
		 con = DBConnection.createConnection();
		 String query = "insert into jobad(job_title,job_description,job_date,company_id,job_postdate) values (?,?,?,?,?)";
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 preparedStatement.setString(1,jobtitle);
		 preparedStatement.setString(2,jobdescription);
		 preparedStatement.setString(3,jobdate);
		 preparedStatement.setString(4,companyid);
		 preparedStatement.setString(5,jobpost_date);
		 int i= preparedStatement.executeUpdate();
		 if (i!=0)  //Just to ensure data has been inserted into the database
		 return "SUCCESS"; 
		 }// On failure, send a message from here.
		 catch (Exception e) 
		 {
			// TODO: handle exception
			 e.printStackTrace();
			 System.out.println("sql error:"+e.getMessage());
		 }
			return "Oops.. Something went wrong there..!"; 
	}

}
