package com.util;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection 
{
	public static Connection createConnection()
	 {
	 Connection con = null;
	 String url = "jdbc:oracle:thin:@localhost:1521:xe";
	 String username = "system";
	 String password = "123456";
	  
	 try
	 {
	 try
	 {
	  Class.forName("oracle.jdbc.driver.OracleDriver");
	 } 
	 catch (ClassNotFoundException e)
	 {
	 e.printStackTrace();
	 }
	  con = DriverManager.getConnection(url, username, password);
	 } 
	 catch (Exception e) 
	 {
	 e.printStackTrace();
	 }
	 return con; 
	 }

}
