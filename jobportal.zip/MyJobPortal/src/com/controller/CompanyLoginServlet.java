package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.CompanyBean;
import com.bean.JobBean;
import com.dao.CompanyLoginDao;
import com.dao.LoginDao;


public class CompanyLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompanyLoginServlet() {
       
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		String email = request.getParameter("companyemail");
		String password = request.getParameter("companypassword");
		//creating an object for model class
		CompanyBean companyBean=new CompanyBean();
		companyBean.setCompany_email(email);
		companyBean.setCompany_password(password);
		 CompanyLoginDao loginDao = new CompanyLoginDao();
			//The core Logic of the Registration application is present here. We are going to insert user data in to the database.
			 Boolean userRegistered = loginDao.loginUser(companyBean);
			 System.out.println("login response" +String.valueOf(userRegistered));
			 if(userRegistered.equals(true))   //On success, you can display a message to user on Home page
			 {
//				 HttpSession session = request.getSession();
//				 session.setAttribute("MySessionVariable", email);
				 HttpSession session = request.getSession();
				  String companyid=loginDao.companyId();
				   System.out.println("Companyiddd" +companyid);
					 session.setAttribute("companyid",companyid);
			     request.getRequestDispatcher("/companyhomepage.jsp").forward(request, response);
			  
			 }
			 else  
				 //On Failure, display a meaningful message to the User.
			 {
			 request.setAttribute("errMessage", userRegistered);
			 request.getRequestDispatcher("/companylogin.jsp").forward(request, response);
			 }
		
		
	}

}
