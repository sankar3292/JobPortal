package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.RegisterBean;
import com.dao.LoginDao;
import com.util.DBConnection;


public class LoginServlet  extends HttpServlet 
{
	
   String page="userpage.jsp";
	private static final long serialVersionUID = 1L;
	 
	 public LoginServlet() 
	 {
		 
	 }
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	 {
	//Copying all the input parameters in to local variables
		 List dataList=new ArrayList(); 
	String email = request.getParameter("email");
	String password = request.getParameter("password");
	//creating an object for model class
	 RegisterBean registerBean = new RegisterBean();
	 registerBean.setEmail(email);
	 registerBean.setPassword(password); 
	 LoginDao loginDao = new LoginDao();
	//The core Logic of the Registration application is present here. We are going to insert user data in to the database.
	 Boolean userRegistered = loginDao.loginUser(registerBean);
	 System.out.println("login response" +String.valueOf(userRegistered));
	 if(userRegistered.equals(true))   //On success, you can display a message to user on Home page
	 {
//		 HttpSession session = request.getSession();
//		 session.setAttribute("MySessionVariable", email);
//	   request.getRequestDispatcher("/userpage.jsp").forward(request, response);
		
		 Boolean status;
		 Connection con = null;
		 ResultSet rs;
		// TODO Auto-generated method stub
		try
		 {
			 con = DBConnection.createConnection();
			 String sql1="select * from jobad";
			 String sql = " select j.JOB_TITLE ,j.JOB_DESCRIPTION,j.JOB_DATE,c.COMPANY_NAME,c.COMPANY_ADDRESS,c.COMPANY_PHONE  from JOBAD j, COMPANY_ACCOUNT c where c.COMPANY_ID=j.COMPANY_ID ";
		
			 Statement s = con.createStatement(); 
			 
			 s.executeQuery (sql);
				rs = s.getResultSet();
				while (rs.next()){
					//Add records into data list
					dataList.add(rs.getString("job_title"));
					dataList.add(rs.getString("job_description"));
					dataList.add(rs.getString("job_date"));
					dataList.add(rs.getString("company_name"));
					dataList.add(rs.getString("company_address"));
					dataList.add(rs.getString("company_phone"));
					
				}
				 System.out.println("listr:"+String.valueOf(rs));
				rs.close ();
				s.close ();
	
			 }
			 catch(SQLException e)
			 {
			 e.printStackTrace();
			 System.out.println("sql error:"+e.getMessage());
			 }
		  // On failure, send a message from here.
		
		request.setAttribute("data",dataList);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(page);
		if (dispatcher != null)
		{
			dispatcher.forward(request, response);
		} 
	}
		
		
	  
	 else  
		 //On Failure, display a meaningful message to the User.
	 {
	 request.setAttribute("errMessage", userRegistered);
	 request.getRequestDispatcher("/login.jsp").forward(request, response);
	 }
}
}
	


