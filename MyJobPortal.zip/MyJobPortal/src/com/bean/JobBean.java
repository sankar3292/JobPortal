package com.bean;

public class JobBean 
{

	private String job_title,job_description,company_id,job_date,job_postdate;

	public String getJob_title() {
		return job_title;
	}

	public void setJob_title(String job_title) {
		this.job_title = job_title;
	}

	public String getJob_description() {
		return job_description;
	}

	public void setJob_description(String job_description) {
		this.job_description = job_description;
	}

	public String getCompany_id() {
		return company_id;
	}

	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}

	public String getJob_date() {
		return job_date;
	}

	public void setJob_date(String job_date) {
		this.job_date = job_date;
	}

	public String getJob_postdate() {
		return job_postdate;
	}

	public void setJob_postdate(String job_postdate) {
		this.job_postdate = job_postdate;
	}
}
