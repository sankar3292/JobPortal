package com.bean;

public class RegisterBean 
{
	 private String country;
	 private String firstname,lastname;
	 private String email;
	 private String password;
	 private String gender;
	 private String phone_no;
	 private String usertype_id,useracc_id;
	 private String user_id;
	 private String dob;
	 private String work_experience,education;
	  

	 public String getPassword() 
	 {
	 return password;
	 }
	 public void setPassword(String password) 
	 {
	 this.password = password;
	 }
	 public void setEmail(String email) 
	 {
	 this.email = email;
	 }
	 public String getEmail() 
	 {
	 return email;
	 }
	public String getGender() 
	{
		return gender;
	}
	public void setGender(String gender) 
	{
		this.gender = gender;
	}
	public String getPhone_no() 
	{
		return phone_no;
	}
	public void setPhone_no(String phone_no) 
	{
		this.phone_no = phone_no;
	}
	public String getUsertype_id() 
	{
		return usertype_id;
	}
	public void setUsertype_id(String usertype_id) 
	{
		this.usertype_id = usertype_id;
	}
	public String getUser_id() 
	{
		return user_id;
	}
	public void setUser_id(String user_id) 
	{
		this.user_id = user_id;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getWork_experience() {
		return work_experience;
	}
	public void setWork_experience(String work_experience) {
		this.work_experience = work_experience;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getUseracc_id() {
		return useracc_id;
	}
	public void setUseracc_id(String useracc_id) {
		this.useracc_id = useracc_id;
	}

}
