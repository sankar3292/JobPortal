package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bean.RegisterBean;
import com.util.DBConnection;



public class RegisterDao 
{
	public String registerUser(RegisterBean registerBean)
	{
	 String firstname=registerBean.getFirstname();
	 String lastname=registerBean.getLastname();
	 String gender=registerBean.getGender();
	 String phone_no=registerBean.getPhone_no();
	 String email = registerBean.getEmail();
	 String password = registerBean.getPassword();
	 String dob=registerBean.getDob();
	 String country=registerBean.getCountry();
	 String education=registerBean.getEducation();
	 String workexp=registerBean.getWork_experience();
	 String useracc_id=registerBean.getUseracc_id();
	 Connection con = null;
	 PreparedStatement preparedStatement = null;
	 try
	 {
	 con = DBConnection.createConnection();
	 String query = "insert into user_account(firstname,lastname,email,phone_no,password,gender,country,work_experience,useracc_id,dob,education) values (?,?,?,?,?,?,?,?,?,?,?)"; //Insert user details into the table 'USERS'
	 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
	 preparedStatement.setString(1,firstname);
	 preparedStatement.setString(2,lastname);
	 preparedStatement.setString(3,email);
	 preparedStatement.setString(4,phone_no);
	 preparedStatement.setString(5,password);
	 preparedStatement.setString(6,gender); 
	 preparedStatement.setString(7,country); 
	 preparedStatement.setString(8,workexp); 
	 preparedStatement.setString(9,useracc_id);
	 preparedStatement.setString(10,dob);
	 preparedStatement.setString(11,education);
	 int i= preparedStatement.executeUpdate();
	 if (i!=0)  //Just to ensure data has been inserted into the database
	 return "SUCCESS"; 
	 }
	 catch(SQLException e)
	 {
	 e.printStackTrace();
	 System.out.println("sql error:"+e.getMessage());
	 }
	 return "Oops.. Something went wrong there..!";  // On failure, send a message from here.
	 }
}
