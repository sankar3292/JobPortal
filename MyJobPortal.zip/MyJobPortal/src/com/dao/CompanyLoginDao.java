package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.CompanyBean;
import com.bean.JobBean;
import com.bean.RegisterBean;
import com.util.DBConnection;

public class CompanyLoginDao 
{
	String company_id;
	public Boolean loginUser(CompanyBean companyBean)
	{
		 String email = companyBean.getCompany_email();
		 String password = companyBean.getCompany_password();
		 Boolean status;
		 Connection con = null;
		 try
		 {
			 con = DBConnection.createConnection();
			 PreparedStatement ps=con.prepareStatement(  
					 "select * from company_account where company_email=? and company_password=?");  
			 ps.setString(1,email);  
			 ps.setString(2,password);  
			 ResultSet rs=ps.executeQuery();  
			
//			 String company_name=rs.getString(1);3
			
			 status=rs.next();  
			 JobBean registerBean=new JobBean();
			  company_id=rs.getString(1);
			 System.out.println("company id:"+company_id);
			 registerBean.setCompany_id(company_id);
			 return status; 
			
			 }
			 catch(SQLException e)
			 {
			 e.printStackTrace();
			 System.out.println("sql error:"+e.getMessage());
			 }
		 return false;  // On failure, send a message from here.
	}
	public String companyId()
	{
		return company_id;
	}

}
