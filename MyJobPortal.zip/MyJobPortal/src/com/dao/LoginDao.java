package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.RegisterBean;
import com.util.DBConnection;


public class LoginDao 
{
	public Boolean loginUser(RegisterBean registerBean)
	{
		 String email = registerBean.getEmail();
		 String password = registerBean.getPassword();
		 Boolean status;
		 Connection con = null;
		 try
		 {
			 con = DBConnection.createConnection();
			 PreparedStatement ps=con.prepareStatement(  
					 "select * from user_account where email=? and password=?");  
			 ps.setString(1,email);  
			 ps.setString(2,password);  
			 ResultSet rs=ps.executeQuery();  
			 status=rs.next();  
			 System.out.println("sql statement" +String.valueOf(ps));
	
			 return status; 
			 }
			 catch(SQLException e)
			 {
			 e.printStackTrace();
			 System.out.println("sql error:"+e.getMessage());
			 }
			 return false;  // On failure, send a message from here.
			 }
}

