package com.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.JobBean;
import com.dao.CompanyRegisterDao;
import com.dao.PostJobDao;

/**
 * Servlet implementation class PostAdServlet
 */

public class PostAdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostAdServlet() {
      
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String job_title=request.getParameter("jobtitle");
		HttpSession session = request.getSession(true);
		String company_id=request.getParameter((String) request.getAttribute("companyid"));
		String job_description=request.getParameter("jobdescription");
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		String job_date=request.getParameter("jobdate");
		System.out.println(df.format(dateobj));
		String job_posteddate=df.format(dateobj);
		JobBean jobBean=new JobBean();
		jobBean.setJob_title(job_title);
		jobBean.setJob_date(job_date);
		jobBean.setJob_description(job_description);
		jobBean.setJob_postdate(job_posteddate);
		jobBean.setCompany_id(company_id);
		//The core Logic of the Registration application is present here. We are going to insert user data in to the database.
		 String userRegistered =PostJobDao.postJob(jobBean);
		  
	 if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {
		   
		
		 }
		 else   //On Failure, display a meaningful message to the User.
	 {
	 request.setAttribute("errMessage", userRegistered);
	 request.getRequestDispatcher("/companyhomepage.jsp").forward(request, response);
		 }
		
	}

}
