package com.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.RegisterBean;
import com.dao.RegisterDao;


public class RegisterServlet extends HttpServlet
{
		 private static final long serialVersionUID = 1L;
		 
		 public RegisterServlet() 
		 {
			 
		 }
		 
		 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		 {
		//Copying all the input parameters in to local variables

		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String gender=request.getParameter("sex");
		String phoneno=request.getParameter("phone");
//		String confirmpassword=request.getParameter("confirm");
		String country=request.getParameter("country");
		String dob=request.getParameter("dob");
		String work_experience=request.getParameter("workexp");
		String education=request.getParameter("education");
		
		//creating an object for model class
		
		 RegisterBean registerBean = new RegisterBean();
		 registerBean.setFirstname(firstname);
		 registerBean.setEmail(email);
		 registerBean.setGender(gender);
		 registerBean.setPhone_no(phoneno);
		 registerBean.setPassword(password); 
		 registerBean.setEducation(education);
		 registerBean.setWork_experience(work_experience);		 
		 registerBean.setDob(dob); 
		 registerBean.setCountry(country);
		 registerBean.setLastname(lastname);
		 registerBean.setUseracc_id("1");
		 RegisterDao registerDao = new RegisterDao();
		  
		//The core Logic of the Registration application is present here. We are going to insert user data in to the database.
		 String userRegistered = registerDao.registerUser(registerBean);
		  
		 if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {
		 request.getRequestDispatcher("/homepage.jsp").forward(request, response);
		 }
		 else   //On Failure, display a meaningful message to the User.
		 {
		 request.setAttribute("errMessage", userRegistered);
		 request.getRequestDispatcher("/register.jsp").forward(request, response);
		 }
	}

}
