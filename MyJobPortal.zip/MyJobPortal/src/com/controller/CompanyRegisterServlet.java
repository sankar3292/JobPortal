package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.CompanyBean;
import com.bean.RegisterBean;
import com.dao.CompanyRegisterDao;



public class CompanyRegisterServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompanyRegisterServlet() {
      
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("companyname");
		String email = request.getParameter("companyemail");
		String password = request.getParameter("companypassword");
		String phoneno=request.getParameter("companyphone");
		String address=request.getParameter("companyaddress");
		String country=request.getParameter("companycountry");
		String industry=request.getParameter("companyindustry");
		//Setting values to Bean class
		CompanyBean companyBean=new CompanyBean();
		companyBean.setCompany_name(name);
		companyBean.setCompany_email(email);
		companyBean.setCompany_password(password);
		companyBean.setCompany_phone(phoneno);
		companyBean.setCompany_address(address);
		companyBean.setCompany_industry(industry);
		companyBean.setCompany_country(country);
		//The core Logic of the Registration application is present here. We are going to insert user data in to the database.
		 String userRegistered = CompanyRegisterDao.registerEmployer(companyBean);
		  
	 if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {
		 request.getRequestDispatcher("/companylogin.jsp").forward(request, response);
		
		 }
		 else   //On Failure, display a meaningful message to the User.
	 {
	 request.setAttribute("errMessage", userRegistered);
	 request.getRequestDispatcher("/register.jsp").forward(request, response);
		 }
	}

}
